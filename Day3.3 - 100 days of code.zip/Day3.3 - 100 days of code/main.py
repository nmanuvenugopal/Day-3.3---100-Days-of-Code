"""
Program predict whether an input year is Leap year or not.
For a year to be Leap year it should follow below criteria:
It should be evenly divisible by 4 (2000 % 4 == 0, Leap Year) .
It should not be divisible by 100 (2000 % 100 == 0, not Leap Year).
It should be divisible by 400 (2000 % 400 == 0,  Leap Year)..
"""

year = int(input("Enter the year: "))

if year % 4 == 0:
    if year % 100 == 0:
        if year % 400 == 0:
            print(f"{year} is leap year")
        else:
            print(f"{year} is not a leap year")
    else:
        print(f"{year} is  a leap year")
else:
    print(f"{year} is not a leap year")
